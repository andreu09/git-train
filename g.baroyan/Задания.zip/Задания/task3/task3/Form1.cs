﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace task3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
            textBox2.Clear();
        }

        private void оПрограммеToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Написать программу - поиск счастливого билета – посчитать сумму " +
                "половины знаков числа слева и справа, и сравнить результат.Счастливым " +
                "считается билет у которого сумма левых и правых знаков равна.\n" +
                "Выполнил: Бароян Гиоргий");
        }

        //Рассчёт
        private void button4_Click(object sender, EventArgs e)
        {
            int koll1 = 0, koll2 = 0;

            int znach;
            if (Int32.TryParse(textBox1.Text, out znach) == true)
            {
                    if (textBox1.Text.Length % 2 == 0)
                    {

                        for (int i = 0; i < textBox1.Text.Length / 2; i++)
                        {

                            koll1 += Convert.ToInt32(textBox1.Text[i]);
                        }

                        for (int i = textBox1.Text.Length / 2; i < textBox1.Text.Length; i++)
                        {

                            koll2 += Convert.ToInt32(textBox1.Text[i]);
                        }

                        if (koll1 == koll2) textBox2.Text = "Билет является счастливым.";

                        else textBox2.Text = "Билет не является счастливым.";

                    }
                    else MessageBox.Show("Введите четное количиство символов!");
            }
            else MessageBox.Show("Корректно заполните строку!");
        }
    }
}
