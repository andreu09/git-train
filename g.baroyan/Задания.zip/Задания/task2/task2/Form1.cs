﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace task2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        //Закрыть
        private void button3_Click_1(object sender, EventArgs e)
        {
            this.Close();
        }

        //О программе
        private void оПрограммеToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            MessageBox.Show("Написать программу, которая проверяет строку на то является ли она палиндромом." +
                "Считать что строка из одной буквы палиндром. " +
                "В качестве результата программа должна вывести true/false." +
                "Выполнил: Бароян Гиоргий");
        }

        //Очистить
        private void button2_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
            textBox2.Clear();
        }

        //Рассчёт
        private void button4_Click(object sender, EventArgs e)
        {
            string koll1="" , koll2 = "";

            if (textBox1.Text.Length == 0) MessageBox.Show("Заполните строку!");
            else
            {
                for (int i = 0; i < textBox1.Text.Length; i++)
                {

                    koll1 += textBox1.Text[i];
                }

                for (int i = textBox1.Text.Length; i > 0; i--)
                {

                    koll2 += textBox1.Text[i - 1];
                }
            }
            if (koll1 == koll2) textBox2.Text = "Строка является палиндромом.";
            else textBox2.Text = "Строка не является палиндромом.";

        }
    }
}
