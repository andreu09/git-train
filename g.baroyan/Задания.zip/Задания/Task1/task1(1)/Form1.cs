﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace task1_1_
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            table.ColumnCount = 3;
            table.RowCount = 3;
        }

        //Заполнить
        private void button4_Click(object sender, EventArgs e)
        {
            int RandMax = Convert.ToInt32(diapozon.Value);
            Random Rand = new Random();
            for (int i = 0; i < table.ColumnCount; i++)
                for (int j = 0; j < table.RowCount; j++)
                    table[i, j].Value = Rand.Next(RandMax);
            textBox_1.Clear();
        }

        //Выход
        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();

        }

        private void оПрограммеToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show(" Есть матрица 2n - 1 x 2n - 1, заполненная случайными значениями.Надо вывести их на экран в ряд," +
              "начиная из центра по спирали: влево - вниз – вправо – вверх и тд.\n" +
              " Выполнил: Бароян Гиоргий.");
        }

        private void kolvo_ValueChanged(object sender, EventArgs e)
        {
            table.ColumnCount = Convert.ToInt32(kolvo.Value) * 2 - 1;//Кол-во столбцов
            table.RowCount = Convert.ToInt32(kolvo.Value) * 2 - 1;//Кол-во строк

            for (int i = 0; i < table.ColumnCount; i++)
                for (int j = 0; j < table.RowCount; j++)
                    table[i, j].Value = " ";
            textBox_1.Clear();
        }

        //Рассчитать
        private void button1_Click(object sender, EventArgs e)
        {
            int n = table.ColumnCount;
            int koll;



            int shagStolb;
            int shagStroka;
            int i = 0;
            int j = 0;

            int DopshagStolb = -1;
            int DopshagStroka = -1;

            textBox_1.Text += table[n / 2, n / 2].Value + " "; //Центр матрицы
            for (koll = 1; koll <= n * n / 2; koll++)
            {

                i++;
                j++;
                DopshagStolb++;
                DopshagStroka++;

                // строка влево
                for (shagStolb = i; shagStolb <= i; shagStolb++)
                {
                    textBox_1.Text += table[n / 2 - shagStolb, n / 2 - DopshagStroka].Value + " "; koll++; //Влево
                }
                for (shagStolb = i; shagStolb <= i; shagStolb++)
                {
                    for (shagStroka = i; shagStroka <= i; shagStroka++)
                    {
                        textBox_1.Text += table[n / 2 - shagStolb, n / 2 + shagStroka].Value + " "; koll++;// Вниз
                    }
                }
                for (shagStolb = i; shagStolb <= i; shagStolb++)

                {
                    for (shagStroka = i; shagStroka <= i; shagStroka++)
                    {
                        textBox_1.Text += table[n / 2, n / 2 + shagStroka].Value + " "; koll++;
                    }
                }
                for (shagStolb = i; shagStolb <= i; shagStolb++)
                {
                    for (shagStroka = i; shagStroka <= i; shagStroka++)
                    {
                        textBox_1.Text += table[n / 2 + shagStolb, n / 2 + shagStroka].Value + " "; koll++;
                    }
                }
                for (shagStolb = i; shagStolb <= i; shagStolb++)
                {
                    textBox_1.Text += table[n / 2 + shagStolb, n / 2].Value + " "; koll++;
                }
                for (shagStolb = i; shagStolb <= i; shagStolb++)
                {
                    for (shagStroka = i; shagStroka <= i; shagStroka++)
                    {
                        textBox_1.Text += table[n / 2 + shagStolb, n / 2 - shagStroka].Value + " "; koll++;
                    }
                }
                for (shagStolb = i; shagStolb <= i; shagStolb++)
                {
                    for (shagStroka = i; shagStroka <= i; shagStroka++)
                    {
                        textBox_1.Text += table[n / 2, n / 2 - shagStroka].Value + " "; koll++;
                    }
                }
                for (shagStolb = i; shagStolb <= i; shagStolb++)
                {
                    for (shagStroka = i; shagStroka <= i; shagStroka++)
                    {
                        textBox_1.Text += table[n / 2 - shagStolb, n / 2 - shagStroka].Value + " "; koll++;
                    }
                }


            }
        }

        //Очистить
        private void button2_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < table.ColumnCount; i++)
                for (int j = 0; j < table.RowCount; j++)
                    table[i, j].Value = " ";
            textBox_1.Clear();
        }
    }
}
